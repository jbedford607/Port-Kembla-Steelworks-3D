#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include "llama.h"

static std::mutex mutex;
static llama_model * model = nullptr;
static bool backendReady = false;

static void batch_set(llama_batch_ext * batch, const llama_token * tokens, int count, int start) {
    llama_batch_ext_clear(batch);
    for(int i=0; i<count; ++i) {
        int idx=llama_batch_ext_add_token(batch,0,tokens[i]);
        llama_batch_ext_set_pos(batch,idx,start+i);
    }
    if(count>0) llama_batch_ext_set_output_logits(batch,count-1,true);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_localaxis_assistant_NativeBrain_load(JNIEnv * env,jclass,jstring modelPath) {
    std::lock_guard<std::mutex> guard(mutex);
    if(!modelPath) return JNI_FALSE;
    const char * path=env->GetStringUTFChars(modelPath,nullptr);
    if(!backendReady) { llama_backend_init();backendReady=true; }
    if(model) { llama_model_free(model);model=nullptr; }
    llama_model_params mp=llama_model_default_params();
    mp.n_gpu_layers=0; mp.use_mmap=true;
    model=llama_model_load_from_file(path,mp);
    env->ReleaseStringUTFChars(modelPath,path);
    return model?JNI_TRUE:JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_localaxis_assistant_NativeBrain_generate(JNIEnv * env,jclass,jstring jprompt,jint maxTokens) {
    std::lock_guard<std::mutex> guard(mutex);
    if(!model||!jprompt)return env->NewStringUTF("Model is not loaded");
    const char *chars=env->GetStringUTFChars(jprompt,nullptr);
    std::string prompt(chars);
    env->ReleaseStringUTFChars(jprompt,chars);
    int maxNew=std::max(8,std::min(400,(int)maxTokens));
    const llama_vocab * vocab=llama_model_get_vocab(model);
    int needed= -llama_tokenize(vocab,prompt.data(),prompt.size(),nullptr,0,true,true);
    if(needed<=0 || needed>2500)return env->NewStringUTF("Prompt too long");
    std::vector<llama_token> tokens((size_t)needed);
    int count=llama_tokenize(vocab,prompt.data(),prompt.size(),tokens.data(),needed,true,true);
    if(count<=0)return env->NewStringUTF("Cannot tokenize prompt");
    llama_context_params cp=llama_context_default_params();
    cp.n_ctx=count+maxNew+8;
    cp.n_batch=count;
    cp.n_threads=4;
    cp.n_threads_batch=4;
    llama_context * ctx=llama_init_from_model(model,cp);
    if(!ctx)return env->NewStringUTF("Model could not allocate memory");
    llama_batch_ext * batch=llama_batch_ext_init(ctx);
    llama_sampler * smpl=llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl,llama_sampler_init_greedy());
    batch_set(batch,tokens.data(),count,0);
    int n_tokens=count;
    std::string output;
    for(int pos=0;pos<count+maxNew;) {
        if(llama_process(ctx,LLAMA_PROCESS_TYPE_DECODE,batch)!=0) {
            if(output.empty())output="Inference failed";
            break;
        }
        pos+=n_tokens;
        llama_token id=llama_sampler_sample(smpl,ctx,-1);
        if(llama_vocab_is_eog(vocab,id))break;
        int len=llama_token_to_piece(vocab,id,nullptr,0,0,true);
        std::vector<char>buf(len<0?(size_t)(-len+2):128);
        int n=llama_token_to_piece(vocab,id,buf.data(),buf.size(),0,true);
        if(n>0)output.append(buf.data(),n);
        if((int)output.size()>3000)break;
        batch_set(batch,&id,1,pos);
        n_tokens=1;
    }
    llama_sampler_free(smpl);
    llama_batch_ext_free(batch);
    llama_free(ctx);
    // NewStringUTF requires modified UTF-8; keep a safe fallback for malformed decoding.
    if(output.empty())output="No response";
    return env->NewStringUTF(output.c_str());
}
