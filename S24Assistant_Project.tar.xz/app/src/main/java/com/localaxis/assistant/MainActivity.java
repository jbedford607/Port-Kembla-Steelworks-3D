package com.localaxis.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements RecognitionListener {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SpeechRecognizer speech;
    private TextToSpeech tts;
    private EditText command;
    private TextView status;
    private Button mic;
    private final int DARK = 0xff101216, BOX = 0xff1d2229, FG = 0xfff1f4f7, ACCENT = 0xffff8537;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(DARK);
        getWindow().setNavigationBarColor(DARK);
        makeUi();
        tts = new TextToSpeech(this, ok -> { if(ok == TextToSpeech.SUCCESS) tts.setLanguage(Locale.ENGLISH); });
    }
    @Override protected void onResume() { super.onResume(); if(status!=null) updateStatus(); }
    private int px(int dp) { return (int)(dp*getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();g.setColor(color);g.setCornerRadius(px(radius));return g;
    }
    private TextView text(String s, int size, int color) {
        TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(size);return v;
    }
    private Button button(String s, boolean primary, LinearLayout root, int top) {
        Button b = new Button(this);b.setText(s);b.setTextColor(primary?DARK:FG);b.setTextAllCaps(false);b.setTextSize(15);
        b.setBackground(bg(primary?ACCENT:BOX,12));b.setMinHeight(px(52));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,px(52));lp.topMargin=px(top);root.addView(b,lp);
        return b;
    }
    private void makeUi() {
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(DARK);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(px(22),px(28),px(22),px(30));sc.addView(root);setContentView(sc);
        TextView title=text("S24 ASSISTANT",24,FG);title.setTypeface(null,Typeface.BOLD);root.addView(title);
        TextView hint=text("Local voice and screen control",13,0xffa3abb6);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=px(4);root.addView(hint,hp);
        status=text("",14,0xffccd0d7);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);
        sp.topMargin=px(24);sp.bottomMargin=px(16);root.addView(status,sp);
        Button access=button("Enable screen controls",false,root,0);
        access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button assistant=button("Set as default assistant",false,root,10);
        assistant.setOnClickListener(v->requestAssistant());
        mic=button("Tap to speak",true,root,24);mic.setOnClickListener(v->listen());
        command=new EditText(this);command.setTextSize(16);command.setTextColor(FG);command.setHintTextColor(0xff939eaa);
        command.setSingleLine(false);command.setMinLines(2);command.setMaxLines(5);
        command.setHint("tap Settings, circle Login, type hello, scroll down...");
        command.setBackground(bg(BOX,12));command.setPadding(px(14),px(12),px(14),px(12));
        command.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=px(20);root.addView(command,cp);
        Button run=button("Run command",false,root,12);run.setOnClickListener(v->execute(command.getText().toString()));
        TextView help=text("Commands: tap [label], circle [label], type [text], scroll up/down, back, home, recents, notifications, quick settings, read screen, open [app]. You can chain actions with 'then'.",13,0xffa5aeb7);
        LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,-2);hlp.topMargin=px(20);root.addView(help,hlp);
        updateStatus();
    }
    private void updateStatus() {
        boolean access = AssistAccess.active!=null;
        boolean offline = SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
        status.setText("Screen control: " + (access?"Enabled":"Disabled") + "\nOffline speech: " + (offline?"Available":"Unavailable on this phone"));
    }
    private void requestAssistant() {
        if (Build.VERSION.SDK_INT>=29) {
            RoleManager roles=(RoleManager)getSystemService(ROLE_SERVICE);
            if (roles!=null && roles.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                startActivityForResult(roles.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT),23);return;
            }
        }
        startActivity(new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS));
    }
    private void listen() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},101); return;
        }
        if(!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            inform("Offline speech recognition is unavailable. Use typed commands or enable an on-device recognizer in Android settings.");return;
        }
        try {
            if(speech!=null){speech.destroy();speech=null;}
            speech=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            speech.setRecognitionListener(this);
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-AU");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
            speech.startListening(i);
            mic.setText("Listening...");
        } catch(Exception e) { inform("Offline recognition could not start"); }
    }
    private void inform(String message) {
        if(status!=null)status.setText(message);
        Toast.makeText(getApplicationContext(),message,Toast.LENGTH_LONG).show();
    }
    private void say(String message) {
        if(tts!=null && message!=null) tts.speak(message.length()>280?message.substring(0,280):message,TextToSpeech.QUEUE_FLUSH,null,"response");
        Toast.makeText(getApplicationContext(),message.length()>180?message.substring(0,180):message,Toast.LENGTH_LONG).show();
    }
    private void execute(String original) {
        String input=original.trim();
        if(input.isEmpty()){inform("Enter or speak a command");return;}
        // Never transmit screen contents or audio to a server.
        command.clearFocus();
        if(input.toLowerCase(Locale.ROOT).startsWith("open ")) {
            String app=input.substring(5).trim();
            String result=openApp(app);say(result);return;
        }
        if(AssistAccess.active==null) { inform("Enable the S24 Assistant accessibility service first");return; }
        String[] steps=input.split("(?i)\\s+then\\s+",5);
        moveTaskToBack(true); // Return to the app which was visible before the assistant.
        ui.postDelayed(()->runStep(steps,0),600);
    }
    private void runStep(String[] steps,int index) {
        if(index>=steps.length)return;
        AssistAccess svc=AssistAccess.active;
        if(svc==null){say("Screen control disconnected");return;}
        String task=steps[index].trim();
        if(task.toLowerCase(Locale.ROOT).startsWith("open ")) {
            say(openApp(task.substring(5).trim()));
        } else {
            String r=svc.act(task);
            say(r);
            if(r.startsWith("Not found")||r.startsWith("Cannot")||r.startsWith("Unsupported")||r.startsWith("Select"))return;
        }
        if(index+1<steps.length)ui.postDelayed(()->runStep(steps,index+1),950);
    }
    private String openApp(String app) {
        Intent finder=new Intent(Intent.ACTION_MAIN);finder.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps=getPackageManager().queryIntentActivities(finder,0);
        ResolveInfo match=null;
        for (ResolveInfo a:apps) {
            String label=a.loadLabel(getPackageManager()).toString();
            if(label.equalsIgnoreCase(app)){match=a;break;}
            if(match==null && label.toLowerCase(Locale.ROOT).contains(app.toLowerCase(Locale.ROOT)))match=a;
        }
        if(match==null)return "App not found: " + app;
        Intent launch=new Intent(Intent.ACTION_MAIN);launch.addCategory(Intent.CATEGORY_LAUNCHER);
        launch.setClassName(match.activityInfo.packageName, match.activityInfo.name);
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {startActivity(launch);return "Opening " + app;}catch(Exception e){return "Cannot launch " + app;}
    }
    @Override public void onRequestPermissionsResult(int request,String[] perms,int[] grant) {
        super.onRequestPermissionsResult(request,perms,grant);
        if(request==101&&grant.length>0&&grant[0]==PackageManager.PERMISSION_GRANTED)listen();
        else if(request==101)inform("Microphone permission is required for voice input");
    }
    @Override protected void onDestroy() {
        if(speech!=null){speech.destroy();speech=null;}
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }
    @Override public void onReadyForSpeech(Bundle params) {}
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float rms) {}
    @Override public void onBufferReceived(byte[] buf) {}
    @Override public void onEndOfSpeech() { mic.setText("Tap to speak"); }
    @Override public void onError(int error) {mic.setText("Tap to speak");inform("Speech recognition error: " + error);}
    @Override public void onResults(Bundle results) {
        mic.setText("Tap to speak");
        java.util.ArrayList<String> words=results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if(words!=null && !words.isEmpty()) {command.setText(words.get(0));execute(words.get(0));}
        else inform("No speech recognised");
    }
    @Override public void onPartialResults(Bundle parts) {}
    @Override public void onEvent(int eventType, Bundle params) {}
}
