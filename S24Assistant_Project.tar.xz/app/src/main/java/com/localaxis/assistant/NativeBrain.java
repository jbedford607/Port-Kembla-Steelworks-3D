package com.localaxis.assistant;

public final class NativeBrain {
    private NativeBrain() {}
    static { System.loadLibrary("s24brain"); }
    public static native boolean load(String path);
    public static native String generate(String prompt, int maxTokens);
}
