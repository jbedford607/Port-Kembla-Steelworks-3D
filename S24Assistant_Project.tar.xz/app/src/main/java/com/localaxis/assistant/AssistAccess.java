package com.localaxis.assistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.content.Context;
import android.util.DisplayMetrics;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AssistAccess extends AccessibilityService {
    static volatile AssistAccess active;
    private WindowManager windowManager;
    private View bubble;
    private View ring;
    private View message;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        active = this;
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        addBubble();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        if (active == this) active = null;
        try { if (bubble != null) windowManager.removeView(bubble); } catch (Exception ignored) { }
        clearRing();
        if(message!=null)try{windowManager.removeView(message);}catch(Exception ignored){}
        super.onDestroy();
    }
    private void addBubble() {
        if (bubble != null) return;
        TextView b = new TextView(this);
        b.setText("A"); b.setTextColor(Color.WHITE); b.setTextSize(21);
        b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xfffb7b30,0xffc8491a});
        bg.setCornerRadius(100); bg.setStroke(2, 0xfffdc6a2);
        b.setBackground(bg);
        b.setOnClickListener(v -> {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        });
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(dp(48), dp(48), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
        p.x = dp(8);
        try { windowManager.addView(b, p); bubble = b; } catch (Exception ignored) { }
    }
    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }

    // All accessibility commands are performed on the UI thread, with the user's explicitly enabled service.
    public String act(String command) {
        String c = command.trim();
        String s = c.toLowerCase(java.util.Locale.ROOT);
        if (s.isEmpty()) return "No command";
        if (s.equals("back") || s.equals("go back") || s.equals("previous screen")) {
            return performGlobalAction(GLOBAL_ACTION_BACK) ? "Back" : "Back unavailable";
        }
        if (s.equals("home") || s.equals("go home")) {
            return performGlobalAction(GLOBAL_ACTION_HOME) ? "Home" : "Home unavailable";
        }
        if (s.equals("recent apps") || s.equals("recents") || s.equals("show recent apps")) {
            return performGlobalAction(GLOBAL_ACTION_RECENTS) ? "Recent apps" : "Recent apps unavailable";
        }
        if (s.equals("notifications") || s.equals("open notifications")) {
            return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ? "Notifications" : "Notifications unavailable";
        }
        if (s.equals("quick settings")) {
            return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) ? "Quick settings" : "Quick settings unavailable";
        }
        if (s.equals("scroll down") || s.equals("swipe up")) return scroll(true);
        if (s.equals("scroll up") || s.equals("swipe down")) return scroll(false);
        if (s.startsWith("tap ") || s.startsWith("click ") || s.startsWith("press ")) {
            String q = c.substring(c.indexOf(' ') + 1).trim();
            return click(q);
        }
        if (s.startsWith("circle ") || s.startsWith("highlight ") || s.startsWith("show me ")) {
            String q = c.substring(c.indexOf(' ') + 1).trim();
            return circle(q);
        }
        if (s.startsWith("type ") || s.startsWith("write ") || s.startsWith("enter ")) {
            return type(c.substring(c.indexOf(' ') + 1));
        }
        if (s.equals("read screen") || s.equals("what's on my screen") || s.equals("what is on my screen") || s.equals("describe screen")) {
            return readScreen();
        }
        return "Unsupported command. Try tap, circle, type, scroll, back, home or read screen.";
    }

    private static void visit(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int limit) {
        if (n == null || out.size() >= limit) return;
        out.add(n);
        for(int i=0;i<n.getChildCount() && out.size()<limit;i++) visit(n.getChild(i),out,limit);
    }
    private List<AccessibilityNodeInfo> nodes() {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) visit(root, out, 2000);
        return out;
    }
    private String label(AccessibilityNodeInfo n) {
        String t = n.getText() == null ? "" : n.getText().toString();
        String d = n.getContentDescription() == null ? "" : n.getContentDescription().toString();
        return (t + " " + d).trim();
    }
    private AccessibilityNodeInfo find(String requested) {
        String q = requested.toLowerCase(java.util.Locale.ROOT).trim();
        AccessibilityNodeInfo fallback = null;
        for (AccessibilityNodeInfo n : nodes()) {
            String text = label(n).toLowerCase(java.util.Locale.ROOT);
            if (text.isEmpty()) continue;
            if (text.equals(q)) return n;
            if (fallback == null && text.contains(q)) fallback = n;
        }
        return fallback;
    }
    public String click(String name) {
        AccessibilityNodeInfo n = find(name);
        if (n == null) return "Not found on screen: " + name;
        AccessibilityNodeInfo a = n;
        while (a != null) {
            if (a.isClickable() && a.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Tapped " + name;
            a = a.getParent();
        }
        Rect r = new Rect(); n.getBoundsInScreen(r);
        if (r.isEmpty()) return "Cannot tap " + name;
        tap(r.centerX(),r.centerY());
        return "Tapping " + name;
    }
    private void tap(int x,int y) {
        Path p = new Path(); p.moveTo(x,y);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();
        dispatchGesture(gesture, null, null);
    }
    public String scroll(boolean down) {
        for (AccessibilityNodeInfo n : nodes()) {
            if (n.isScrollable() && n.performAction(down ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))
                return down ? "Scrolling down" : "Scrolling up";
        }
        DisplayMetrics m = getResources().getDisplayMetrics();
        int x = m.widthPixels / 2; int high = (int)(m.heightPixels * 0.28); int low = (int)(m.heightPixels * 0.72);
        Path p = new Path(); p.moveTo(x,down ? low : high); p.lineTo(x,down ? high : low);
        dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,350)).build(),null,null);
        return down ? "Swiping up" : "Swiping down";
    }
    public String type(String value) {
        AccessibilityNodeInfo focused = null;
        for (AccessibilityNodeInfo n : nodes()) {
            if (n.isFocused() && n.isEditable()) { focused=n; break; }
        }
        if (focused == null) {
            for (AccessibilityNodeInfo n : nodes()) if (n.isEditable()) { focused=n; break; }
        }
        if (focused == null) return "Select a text box first";
        Bundle b = new Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,value);
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b) ? "Text entered" : "Cannot edit this text field";
    }
    public String readScreen() {
        Set<String> results = new java.util.LinkedHashSet<>();
        for (AccessibilityNodeInfo n : nodes()) {
            String s=label(n);
            if (!s.isEmpty() && s.length() < 160 && !s.equals("A")) results.add(s);
            if (results.size() >= 28) break;
        }
        if (results.isEmpty()) return "No readable screen text. This app may block accessibility.";
        return "Visible text: " + android.text.TextUtils.join("; ",results);
    }
    public String circle(String name) {
        AccessibilityNodeInfo n = find(name);
        if (n == null) return "Not found on screen: " + name;
        Rect r = new Rect(); n.getBoundsInScreen(r);
        if (r.isEmpty()) return "Cannot locate " + name;
        clearRing();
        final Rect target = new Rect(r);
        View overlay = new View(this) {
            final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                paint.setColor(0xffff8030); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(4));
                float cx = target.exactCenterX(); float cy = target.exactCenterY();
                float rx = target.width()/2f + dp(12); float ry = target.height()/2f + dp(12);
                canvas.drawOval(cx-rx,cy-ry,cx+rx,cy+ry,paint);
            }
        };
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;
        try { windowManager.addView(overlay,p); ring=overlay; ui.postDelayed(()->{if(ring==overlay)clearRing();},4500); }
        catch(Exception ignored) {return "Overlay not available";}
        return "Circled " + name;
    }
    public void showMessage(String response) {
        ui.post(() -> {
            if(windowManager==null)return;
            try { if(message!=null)windowManager.removeView(message); } catch(Exception ignored){}
            TextView label=new TextView(this);
            label.setText(response.length()>900?response.substring(0,900):response);
            label.setTextSize(15);label.setTextColor(Color.WHITE);
            label.setPadding(dp(18),dp(14),dp(18),dp(14));
            label.setMaxLines(12);
            GradientDrawable bg=new GradientDrawable();bg.setColor(0xf01b232e);bg.setCornerRadius(dp(14));
            bg.setStroke(dp(1),0xfffc8143);label.setBackground(bg);
            WindowManager.LayoutParams p=new WindowManager.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*.9),-2,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
            p.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;p.y=dp(64);
            try {windowManager.addView(label,p);message=label;ui.postDelayed(()->{
                if(message==label){try{windowManager.removeView(label);}catch(Exception ignored){}message=null;}
            },14000);}catch(Exception ignored){}
        });
    }
    private void clearRing() {
        try { if (ring != null && windowManager != null) windowManager.removeView(ring); } catch(Exception ignored) { }
        ring=null;
    }
}
